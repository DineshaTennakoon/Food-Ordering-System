 <div class="container-xxl position-relative p-0">
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark px-4 px-lg-5 py-3 py-lg-0">
                <a href="" class="navbar-brand p-0">
                    <h1 class="text-primary m-0"><i class="fa fa-utensils me-3"></i>Foodies</h1>
                    <!-- <img src="img/logo.png" alt="Logo"> -->
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                    <span class="fa fa-bars"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <div class="navbar-nav ms-auto py-0 pe-4">
                        <a href="index.php" class="nav-item nav-link active">Home</a>
                        <a href="aboutus.php" class="nav-item nav-link">About</a>
                        <a href="services.php" class="nav-item nav-link">Service</a>
                        <a href="menus.php" class="nav-item nav-link">Menu</a>
                        
                        <a href="contact.php" class="nav-item nav-link">Contact</a>
                    </div>
                 <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Login</a>
                     <div class="dropdown-menu m-0">
                                <a href="customerlogin.php" class="dropdown-item">Customer</a>
                                <a href="managerlogin.php" class="dropdown-item">Manager</a>
                              
                            </div>
                </div>
            </nav>

          