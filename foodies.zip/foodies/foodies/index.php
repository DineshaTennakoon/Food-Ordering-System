<!DOCTYPE html>
<html lang="en">

<head>
   <?php include('css.php'); ?>
</head>

<body>
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- Navbar & Hero Start -->
         <?php include('nav.php'); ?>
          <div class="container-xxl py-5 bg-dark hero-header mb-5">
                <div class="container my-5 py-5">
                    <div class="row align-items-center g-5">
                        <div class="col-lg-6 text-center text-lg-start">
                            <h1 class="display-3 text-white animated slideInLeft">Choose Your<br>Favourite Dish Here</h1>
                            <p class="text-white animated slideInLeft mb-4 pb-2"></p>
                           
                        </div>
                        <div class="col-lg-6 text-center text-lg-end overflow-hidden">
                            <img class="img-fluid" src="img/hero.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
       
        <!-- Navbar & Hero End -->


        <!-- Service Start -->
       <?php include('service.php'); ?>
        <!-- Service End -->


        <!-- About Start -->
         <?php include('about.php'); ?>
        <!-- About End -->


        <!-- Menu Start -->
           <?php include('menu.php'); ?>
        <!-- Menu End -->


        <!-- Reservation Start -->
        
        <!-- Reservation Start -->


        <!-- Team Start -->
       <?php include('team.php'); ?>
        <!-- Team End -->


        <!-- Testimonial Start -->
    
        <!-- Testimonial End -->
        

        <!-- Footer Start -->
        <?php include('footer.php'); ?>
        <!-- Footer End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
      <?php include('js.php'); ?>
</body>

</html>