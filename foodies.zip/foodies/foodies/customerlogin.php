<!DOCTYPE html>
<html lang="en">

<head>
   <?php include('css.php'); ?>
</head>

<body>
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- Navbar & Hero Start -->
        <div class="container-xxl position-relative p-0">
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark px-4 px-lg-5 py-3 py-lg-0">
                <a href="" class="navbar-brand p-0">
                
                    <!-- <img src="img/logo.png" alt="Logo"> -->
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                    <span class="fa fa-bars"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <?php include('nav.php'); ?>
            </nav>

            <div class="container-xxl py-5 bg-dark hero-header mb-5" >
                
            </div>
        </div>
        <!-- Navbar & Hero End -->
  <div class="container" style="margin-top: 4%; margin-bottom: 2%;" >
      <div class="col-md-6">
          <img src="images\man.jpg" style="width:100%; height: 580px;">
      </div>
      <div class="col-md-6" style="float:right ;margin-top: -500px;>
       <label style="margin-left: 5px;color: red;"><span>  </span></label>
      <div class="panel panel-primary"  ">
        <div class="panel-heading" style="background-color: orange; text-align: center;"> Login </div>
        <div class="panel-body" >
          
        <form action="" method="POST" >
          
        <div class="row">
          <div class="form-group col-xs-12" >
            <label for="username"><span class="text-danger" style="margin-right: 5px;">*</span> Username: </label>
<br>
              <input class="form-control" id="username" type="text" name="username" placeholder="Username" required="" autofocus="">
              <br>
          </div>
        </div>

        <div class="row">
          <div class="form-group col-xs-12">
            <label for="password"><span class="text-danger" style="margin-right: 5px;">*</span> Password: </label>
             <input class="form-control" id="password" type="password" name="password" placeholder="Password" required="">
            
          </div>
        </div>

        <div class="row">
          <div class="col-md-6">
            <br>
              <button class="btn btn-primary" style="background-color: green;" name="submit" type="submit" value=" Login ">Log In</button>

          </div>

          <div class="col-md-6">
            <br>
             <label style="margin-left: 5px;"><a href="managersignup.php">Create a new account.</a></label>
          </div>

        </div>
        
      
       

        </form>
          </div>
        
      </div>
      </div>
        </div>


        <!-- Manager Login Start -->
      








        <!-- Manager Login End -->
        

        <!-- Footer Start -->
        <?php include('footer.php'); ?>
        <!-- Footer End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
     <?php include('js.php'); ?>
</body>

</html>